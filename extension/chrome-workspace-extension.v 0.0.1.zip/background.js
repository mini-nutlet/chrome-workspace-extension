var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/idb/build/index.js
function getIdbProxyableTypes() {
  return idbProxyableTypes || (idbProxyableTypes = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function getCursorAdvanceMethods() {
  return cursorAdvanceMethods || (cursorAdvanceMethods = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
function promisifyRequest(request) {
  const promise = new Promise((resolve, reject) => {
    const unlisten = () => {
      request.removeEventListener("success", success);
      request.removeEventListener("error", error);
    };
    const success = () => {
      resolve(wrap(request.result));
      unlisten();
    };
    const error = () => {
      reject(request.error);
      unlisten();
    };
    request.addEventListener("success", success);
    request.addEventListener("error", error);
  });
  reverseTransformCache.set(promise, request);
  return promise;
}
function cacheDonePromiseForTransaction(tx) {
  if (transactionDoneMap.has(tx))
    return;
  const done = new Promise((resolve, reject) => {
    const unlisten = () => {
      tx.removeEventListener("complete", complete);
      tx.removeEventListener("error", error);
      tx.removeEventListener("abort", error);
    };
    const complete = () => {
      resolve();
      unlisten();
    };
    const error = () => {
      reject(tx.error || new DOMException("AbortError", "AbortError"));
      unlisten();
    };
    tx.addEventListener("complete", complete);
    tx.addEventListener("error", error);
    tx.addEventListener("abort", error);
  });
  transactionDoneMap.set(tx, done);
}
function replaceTraps(callback) {
  idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
  if (getCursorAdvanceMethods().includes(func)) {
    return function(...args) {
      func.apply(unwrap(this), args);
      return wrap(this.request);
    };
  }
  return function(...args) {
    return wrap(func.apply(unwrap(this), args));
  };
}
function transformCachableValue(value) {
  if (typeof value === "function")
    return wrapFunction(value);
  if (value instanceof IDBTransaction)
    cacheDonePromiseForTransaction(value);
  if (instanceOfAny(value, getIdbProxyableTypes()))
    return new Proxy(value, idbProxyTraps);
  return value;
}
function wrap(value) {
  if (value instanceof IDBRequest)
    return promisifyRequest(value);
  if (transformCache.has(value))
    return transformCache.get(value);
  const newValue = transformCachableValue(value);
  if (newValue !== value) {
    transformCache.set(value, newValue);
    reverseTransformCache.set(newValue, value);
  }
  return newValue;
}
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
  const request = indexedDB.open(name, version);
  const openPromise = wrap(request);
  if (upgrade) {
    request.addEventListener("upgradeneeded", (event) => {
      upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
    });
  }
  if (blocked) {
    request.addEventListener("blocked", (event) => blocked(
      // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
      event.oldVersion,
      event.newVersion,
      event
    ));
  }
  openPromise.then((db) => {
    if (terminated)
      db.addEventListener("close", () => terminated());
    if (blocking) {
      db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
    }
  }).catch(() => {
  });
  return openPromise;
}
function getMethod(target, prop) {
  if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
    return;
  }
  if (cachedMethods.get(prop))
    return cachedMethods.get(prop);
  const targetFuncName = prop.replace(/FromIndex$/, "");
  const useIndex = prop !== targetFuncName;
  const isWrite = writeMethods.includes(targetFuncName);
  if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
  ) {
    return;
  }
  const method = async function(storeName, ...args) {
    const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
    let target2 = tx.store;
    if (useIndex)
      target2 = target2.index(args.shift());
    return (await Promise.all([
      target2[targetFuncName](...args),
      isWrite && tx.done
    ]))[0];
  };
  cachedMethods.set(prop, method);
  return method;
}
async function* iterate(...args) {
  let cursor = this;
  if (!(cursor instanceof IDBCursor)) {
    cursor = await cursor.openCursor(...args);
  }
  if (!cursor)
    return;
  cursor = cursor;
  const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
  ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
  reverseTransformCache.set(proxiedCursor, unwrap(cursor));
  while (cursor) {
    yield proxiedCursor;
    cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
    advanceResults.delete(proxiedCursor);
  }
}
function isIteratorProp(target, prop) {
  return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
}
var instanceOfAny, idbProxyableTypes, cursorAdvanceMethods, transactionDoneMap, transformCache, reverseTransformCache, idbProxyTraps, unwrap, readMethods, writeMethods, cachedMethods, advanceMethodProps, methodMap, advanceResults, ittrProxiedCursorToOriginalProxy, cursorIteratorTraps;
var init_build = __esm({
  "node_modules/idb/build/index.js"() {
    instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
    transactionDoneMap = /* @__PURE__ */ new WeakMap();
    transformCache = /* @__PURE__ */ new WeakMap();
    reverseTransformCache = /* @__PURE__ */ new WeakMap();
    idbProxyTraps = {
      get(target, prop, receiver) {
        if (target instanceof IDBTransaction) {
          if (prop === "done")
            return transactionDoneMap.get(target);
          if (prop === "store") {
            return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
          }
        }
        return wrap(target[prop]);
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
      has(target, prop) {
        if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
          return true;
        }
        return prop in target;
      }
    };
    unwrap = (value) => reverseTransformCache.get(value);
    readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
    writeMethods = ["put", "add", "delete", "clear"];
    cachedMethods = /* @__PURE__ */ new Map();
    replaceTraps((oldTraps) => ({
      ...oldTraps,
      get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
      has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
    }));
    advanceMethodProps = ["continue", "continuePrimaryKey", "advance"];
    methodMap = {};
    advanceResults = /* @__PURE__ */ new WeakMap();
    ittrProxiedCursorToOriginalProxy = /* @__PURE__ */ new WeakMap();
    cursorIteratorTraps = {
      get(target, prop) {
        if (!advanceMethodProps.includes(prop))
          return target[prop];
        let cachedFunc = methodMap[prop];
        if (!cachedFunc) {
          cachedFunc = methodMap[prop] = function(...args) {
            advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
          };
        }
        return cachedFunc;
      }
    };
    replaceTraps((oldTraps) => ({
      ...oldTraps,
      get(target, prop, receiver) {
        if (isIteratorProp(target, prop))
          return iterate;
        return oldTraps.get(target, prop, receiver);
      },
      has(target, prop) {
        return isIteratorProp(target, prop) || oldTraps.has(target, prop);
      }
    }));
  }
});

// src/db/database.ts
var database_exports = {};
__export(database_exports, {
  findRule: () => findRule,
  getDb: () => getDb,
  hashUrl: () => hashUrl,
  hashUrlWithRules: () => hashUrlWithRules,
  invalidateSimRulesCache: () => invalidateSimRulesCache,
  loadSimilarityRules: () => loadSimilarityRules,
  matchRule: () => matchRule,
  now: () => now
});
async function migrateLegacyAutoSwitch(rules) {
  if (migrationDone) return rules;
  migrationDone = true;
  try {
    const stored = await chrome.storage.local.get("autoSwitchDomains");
    const domains = stored.autoSwitchDomains || [];
    if (domains.length === 0) return rules;
    const existingPatterns = new Set(
      rules.map((r) => `${r.pattern}|${r.pattern_type}`)
    );
    for (const domain of domains) {
      if (!domain) continue;
      const key = `${domain}|domain`;
      if (existingPatterns.has(key)) continue;
      rules.push({
        id: crypto.randomUUID(),
        pattern: domain,
        pattern_type: "domain",
        rule_type: "ignore_query",
        enabled: true,
        auto_switch: true
      });
    }
    await chrome.storage.local.remove("autoSwitchDomains");
  } catch {
  }
  return rules;
}
async function loadSimilarityRules() {
  if (cachedSimRules) return cachedSimRules;
  if (simRulesLoadPromise) return simRulesLoadPromise;
  simRulesLoadPromise = (async () => {
    try {
      const result = await chrome.storage.local.get("similarityRules");
      const raw = result.similarityRules || [];
      cachedSimRules = raw.map((r) => ({
        id: r.id ?? crypto.randomUUID(),
        pattern: r.pattern ?? r.domain_pattern ?? "",
        pattern_type: r.pattern_type ?? "domain",
        rule_type: r.rule_type ?? "ignore_query",
        enabled: r.enabled !== false,
        auto_switch: r.auto_switch ?? false
      }));
      await chrome.storage.local.set({ similarityRules: cachedSimRules });
      cachedSimRules = await migrateLegacyAutoSwitch(cachedSimRules);
      if (cachedSimRules.length > 0) {
        await chrome.storage.local.set({ similarityRules: cachedSimRules });
      }
    } catch {
      cachedSimRules = [];
    }
    return cachedSimRules;
  })();
  return simRulesLoadPromise;
}
function invalidateSimRulesCache() {
  cachedSimRules = null;
  simRulesLoadPromise = null;
}
function getDb() {
  if (!dbPromise) {
    dbPromise = openDB("workspace-companion", 1, {
      upgrade(db) {
        const wsStore = db.createObjectStore("workspaces", {
          keyPath: "id",
          autoIncrement: true
        });
        wsStore.createIndex("parentId", "parentId");
        wsStore.createIndex("sortOrder", "sortOrder");
        const tabStore = db.createObjectStore("tabs", {
          keyPath: "id",
          autoIncrement: true
        });
        tabStore.createIndex("windowChrome", ["windowId", "chromeTabId"], { unique: true });
        tabStore.createIndex("urlHash", "urlHash");
        const twStore = db.createObjectStore("tabWorkspaces", {
          keyPath: "id",
          autoIncrement: true
        });
        twStore.createIndex("tabWorkspace", ["tabId", "workspaceId"], { unique: true });
        twStore.createIndex("workspaceId", "workspaceId");
        twStore.createIndex("workspaceGroup", ["workspaceId", "groupId"]);
        const tgStore = db.createObjectStore("tabGroups", {
          keyPath: "id",
          autoIncrement: true
        });
        tgStore.createIndex("workspaceId", "workspaceId");
        const bmStore = db.createObjectStore("bookmarks", {
          keyPath: "id",
          autoIncrement: true
        });
        bmStore.createIndex("workspaceId", "workspaceId");
        bmStore.createIndex("urlHash", "urlHash");
        const agStore = db.createObjectStore("autoGroupRules", {
          keyPath: "id",
          autoIncrement: true
        });
        agStore.createIndex("enabled", "enabled");
        db.createObjectStore("sessions", { keyPath: "workspaceId" });
      }
    });
  }
  return dbPromise;
}
function now() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function matchRule(url, rule) {
  try {
    const u = new URL(url);
    const hostname = u.hostname.replace(/^www\./, "").toLowerCase();
    const pathname = u.pathname.toLowerCase();
    const slashIdx = rule.pattern.indexOf("/");
    const patHost = slashIdx === -1 ? rule.pattern.toLowerCase() : rule.pattern.slice(0, slashIdx).toLowerCase();
    const patPath = slashIdx === -1 ? "" : rule.pattern.slice(slashIdx).toLowerCase();
    if (!hostname.includes(patHost.replace(/^www\./, ""))) return false;
    if (rule.pattern_type === "exact_path" || rule.pattern_type === "path_prefix") {
      if (!patPath) return true;
      const normPath = pathname.replace(/\/+$/, "") || "/";
      const normPat = patPath.replace(/\/+$/, "") || "/";
      if (rule.pattern_type === "exact_path") {
        return normPath === normPat;
      }
      if (normPath === normPat) return true;
      return normPath.startsWith(normPat + "/");
    }
    return true;
  } catch {
    return false;
  }
}
function findRule(url, rules) {
  for (const r of rules) {
    if (!r.enabled) continue;
    if (matchRule(url, r)) return r;
  }
  return null;
}
function hashUrl(url) {
  try {
    const u = new URL(url);
    u.search = "";
    u.hostname = u.hostname.replace(/^www\./, "");
    return u.toString().toLowerCase();
  } catch {
    return url.toLowerCase();
  }
}
function hashUrlWithRules(url, simRules) {
  try {
    const u = new URL(url);
    const hostname = u.hostname.replace(/^www\./, "");
    const matchedRule = findRule(url, simRules);
    if (matchedRule) {
      switch (matchedRule.rule_type) {
        case "ignore_path_query":
          return hostname.toLowerCase();
        case "ignore_hash":
          u.hash = "";
          break;
        case "ignore_query":
          u.search = "";
          break;
        case "exact":
          break;
      }
    } else {
      u.search = "";
    }
    return u.toString().toLowerCase();
  } catch {
    return url.toLowerCase();
  }
}
var cachedSimRules, simRulesLoadPromise, migrationDone, dbPromise;
var init_database = __esm({
  "src/db/database.ts"() {
    "use strict";
    init_build();
    cachedSimRules = null;
    simRulesLoadPromise = null;
    migrationDone = false;
    dbPromise = null;
  }
});

// src/db/tabgroup-repo.ts
var tabgroup_repo_exports = {};
__export(tabgroup_repo_exports, {
  createTabGroup: () => createTabGroup,
  deleteTabGroup: () => deleteTabGroup,
  getTabGroupTree: () => getTabGroupTree,
  listGroups: () => listGroups,
  reorderGroups: () => reorderGroups,
  updateTabGroup: () => updateTabGroup
});
function toApi2(row) {
  return {
    id: row.id,
    workspace_id: row.workspaceId,
    name: row.name,
    color: row.color,
    collapsed: row.collapsed !== 0,
    sort_order: row.sortOrder,
    created_at: row.createdAt,
    updated_at: row.updatedAt
  };
}
async function listGroups(workspaceId) {
  const db = await getDb();
  const idx = db.transaction("tabGroups").store.index("workspaceId");
  const rows = await idx.getAll(workspaceId);
  return rows.map(toApi2).sort((a, b) => a.sort_order - b.sort_order || a.id - b.id);
}
async function createTabGroup(workspaceId, name, color = "") {
  const db = await getDb();
  const groups = await listGroups(workspaceId);
  const existing = groups.find((g) => g.name.toLowerCase() === name.toLowerCase());
  if (existing) return existing;
  const sortOrder = groups.length > 0 ? Math.max(...groups.map((g) => g.sort_order)) + 1 : 0;
  const id = await db.add("tabGroups", {
    workspaceId,
    name,
    color,
    collapsed: 0,
    sortOrder,
    createdAt: now(),
    updatedAt: now()
  });
  return toApi2(await db.get("tabGroups", id));
}
async function updateTabGroup(id, updates) {
  const db = await getDb();
  const row = await db.get("tabGroups", id);
  if (!row) return;
  if (updates.name !== void 0) {
    const groups = await listGroups(row.workspaceId);
    const conflict = groups.find(
      (g) => g.id !== id && g.name.toLowerCase() === updates.name.toLowerCase()
    );
    if (conflict) return;
    row.name = updates.name;
  }
  if (updates.color !== void 0) row.color = updates.color;
  if (updates.collapsed !== void 0) row.collapsed = updates.collapsed ? 1 : 0;
  if (updates.sort_order !== void 0) row.sortOrder = updates.sort_order;
  row.updatedAt = now();
  await db.put("tabGroups", row);
}
async function deleteTabGroup(id) {
  const db = await getDb();
  const row = await db.get("tabGroups", id);
  if (!row) return;
  const twList = (await db.getAll("tabWorkspaces")).filter((tw) => tw.groupId === id);
  for (const tw of twList) {
    const tab = await db.get("tabs", tw.tabId);
    await db.delete("tabWorkspaces", tw.id);
    if (tab) {
      if (tab.chromeTabId <= 0) {
        const remaining = (await db.getAll("tabWorkspaces")).filter((r) => r.tabId === tab.id);
        if (remaining.length === 0) {
          await db.delete("tabs", tab.id);
        }
      } else {
        const remaining = (await db.getAll("tabWorkspaces")).filter((r) => r.tabId === tab.id);
        if (remaining.length === 0) {
          await db.delete("tabs", tab.id);
        }
      }
    }
  }
  await db.delete("tabGroups", id);
}
async function reorderGroups(workspaceId, orderedIds) {
  const db = await getDb();
  const tx = db.transaction("tabGroups", "readwrite");
  for (let i = 0; i < orderedIds.length; i++) {
    const row = await tx.store.get(orderedIds[i]);
    if (row && row.workspaceId === workspaceId) {
      row.sortOrder = i;
      await tx.store.put(row);
    }
  }
  await tx.done;
}
async function getTabGroupTree(workspaceId) {
  const groups = await listGroups(workspaceId);
  const allTabs = await listTabsByWorkspace(workspaceId);
  const groupIds = new Set(groups.map((g) => g.id));
  const groupsWithTabs = [];
  for (const g of groups) {
    const tabs = await listTabsByGroup(g.id, workspaceId);
    groupsWithTabs.push({ ...g, tabs });
  }
  const ungroupedTabs = allTabs.filter((t) => t.group_id === 0 || !groupIds.has(t.group_id));
  return { groups: groupsWithTabs, ungrouped_tabs: ungroupedTabs };
}
var init_tabgroup_repo = __esm({
  "src/db/tabgroup-repo.ts"() {
    "use strict";
    init_database();
    init_tab_repo();
  }
});

// src/db/autogroup-repo.ts
var autogroup_repo_exports = {};
__export(autogroup_repo_exports, {
  autoGroupTab: () => autoGroupTab,
  domainToGroupName: () => domainToGroupName,
  listRules: () => listRules,
  reapplyAutoGroup: () => reapplyAutoGroup,
  runAutoGroup: () => runAutoGroup
});
function toApi3(row) {
  return {
    id: row.id,
    domain_pattern: row.domainPattern,
    group_name: row.groupName,
    enabled: row.enabled !== 0,
    sort_order: row.sortOrder,
    created_at: row.createdAt,
    updated_at: row.updatedAt
  };
}
function domainToGroupName(hostname) {
  let name = hostname.replace(/^www\./i, "").toLowerCase();
  name = name.replace(/\.(com|org|net|io|dev|co|gov|edu|ai|app|me|info|biz)(\.[a-z]{2})?$/i, "");
  const known = {
    "github": "GitHub",
    "stackoverflow": "Stack Overflow",
    "youtube": "YouTube",
    "npmjs": "npm",
    "medium": "Medium",
    "google": "Google",
    "wikipedia": "Wikipedia",
    "linkedin": "LinkedIn",
    "gitlab": "GitLab",
    "bitbucket": "Bitbucket",
    "notion": "Notion",
    "figma": "Figma",
    "reddit": "Reddit",
    "whatsapp": "WhatsApp",
    "discord": "Discord",
    "slack": "Slack",
    "gmail": "Gmail",
    "mail.google": "Gmail",
    "docs.google": "Google Docs",
    "drive.google": "Google Drive",
    "calendar.google": "Google Calendar",
    "meet.google": "Google Meet",
    "sheets.google": "Google Sheets",
    "slides.google": "Google Slides",
    "chat.openai": "ChatGPT",
    "chatgpt": "ChatGPT",
    "claude": "Claude",
    "claude.ai": "Claude",
    "copilot.microsoft": "Copilot",
    "outlook.live": "Outlook",
    "outlook.office": "Outlook",
    "bing": "Bing",
    "amazon": "Amazon",
    "netflix": "Netflix",
    "spotify": "Spotify",
    "twitch": "Twitch",
    "news.ycombinator": "Hacker News",
    "twitter": "X/Twitter",
    "x": "X/Twitter",
    "facebook": "Facebook",
    "instagram": "Instagram",
    "tiktok": "TikTok",
    "translate.google": "Google Translate",
    "maps.google": "Google Maps",
    "photos.google": "Google Photos",
    "console.cloud.google": "GCP Console",
    "portal.azure": "Azure Portal",
    "dev.azure": "Azure DevOps",
    "docs.rs": "Rust Docs",
    "crates.io": "Crates.io",
    "pypi.org": "PyPI",
    "docs.python": "Python Docs",
    "developer.mozilla": "MDN",
    "learn.microsoft": "Microsoft Learn"
  };
  const key = name.toLowerCase();
  if (known[key]) return known[key];
  return name.split(".").map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join(" ");
}
async function listRules() {
  const db = await getDb();
  const rows = await db.getAll("autoGroupRules");
  if (rows.length === 0) {
    for (let i = 0; i < DEFAULT_RULES.length; i++) {
      const [pattern, name] = DEFAULT_RULES[i];
      await db.add("autoGroupRules", {
        domainPattern: pattern,
        groupName: name,
        enabled: 1,
        sortOrder: i + 1,
        createdAt: now(),
        updatedAt: now()
      });
    }
    return listRules();
  }
  return rows.map(toApi3).sort((a, b) => a.sort_order - b.sort_order);
}
async function autoGroupTab(tabId, workspaceId, urlHash) {
  const rules = await listRules();
  const { setTabGroup: setTabGroup3 } = await Promise.resolve().then(() => (init_tab_repo(), tab_repo_exports));
  const { listGroups: listGroups2, createTabGroup: createTabGroup2 } = await Promise.resolve().then(() => (init_tabgroup_repo(), tabgroup_repo_exports));
  const db = await getDb();
  const allTw = await db.getAll("tabWorkspaces");
  const tw = allTw.find((r) => r.tabId === tabId && r.workspaceId === workspaceId);
  if (!tw || tw.groupId !== 0) return;
  const tab = await db.get("tabs", tabId);
  if (!tab) return;
  const urlLower = tab.url.toLowerCase();
  const hostname = (() => {
    try {
      return new URL(tab.url).hostname.toLowerCase();
    } catch {
      return tab.url.toLowerCase();
    }
  })();
  for (const rule of rules) {
    if (!rule.enabled) continue;
    const pattern = rule.domain_pattern.toLowerCase();
    if (urlLower.includes(pattern) || hostname.includes(pattern)) {
      const groups = await listGroups2(workspaceId);
      let group = groups.find((g) => g.name.toLowerCase() === rule.group_name.toLowerCase());
      if (!group) {
        group = await createTabGroup2(workspaceId, rule.group_name);
      }
      if (group && group.id > 0) {
        await setTabGroup3(tabId, workspaceId, group.id);
      }
      break;
    }
  }
  const twAfter = (await db.getAll("tabWorkspaces")).find((r) => r.tabId === tabId && r.workspaceId === workspaceId);
  if (twAfter && twAfter.groupId === 0 && hostname) {
    const groupName = domainToGroupName(hostname);
    const groups = await listGroups2(workspaceId);
    let group = groups.find((g) => g.name.toLowerCase() === groupName.toLowerCase());
    if (!group) {
      group = await createTabGroup2(workspaceId, groupName);
    }
    if (group && group.id > 0) {
      await setTabGroup3(tabId, workspaceId, group.id);
    }
  }
}
async function runAutoGroup() {
  const db = await getDb();
  const allTw = await db.getAll("tabWorkspaces");
  let count = 0;
  for (const tw of allTw) {
    if (tw.groupId !== 0) continue;
    const tab = await db.get("tabs", tw.tabId);
    if (!tab) continue;
    await autoGroupTab(tw.tabId, tw.workspaceId, tab.urlHash);
    count++;
  }
  return count;
}
async function reapplyAutoGroup(workspaceId) {
  const db = await getDb();
  const allTw = await db.getAll("tabWorkspaces");
  const tx = db.transaction("tabWorkspaces", "readwrite");
  for (const tw of allTw) {
    if (tw.workspaceId === workspaceId && tw.groupId !== 0) {
      tw.groupId = 0;
      await tx.store.put(tw);
    }
  }
  await tx.done;
  let count = 0;
  const { listTabsByWorkspace: listTabsByWorkspace2 } = await Promise.resolve().then(() => (init_tab_repo(), tab_repo_exports));
  const { listGroups: listGroups2, deleteTabGroup: deleteTabGroup2 } = await Promise.resolve().then(() => (init_tabgroup_repo(), tabgroup_repo_exports));
  const tabs = await listTabsByWorkspace2(workspaceId);
  for (const tab of tabs) {
    await autoGroupTab(tab.id, workspaceId, tab.url_hash || "");
    count++;
  }
  const groups = await listGroups2(workspaceId);
  for (const g of groups) {
    const tws = (await db.getAll("tabWorkspaces")).filter((r) => r.groupId === g.id && r.workspaceId === workspaceId);
    if (tws.length === 0 && g.name !== "Ungrouped") {
      try {
        await deleteTabGroup2(g.id);
      } catch {
      }
    }
  }
  return count;
}
var DEFAULT_RULES;
var init_autogroup_repo = __esm({
  "src/db/autogroup-repo.ts"() {
    "use strict";
    init_database();
    DEFAULT_RULES = [
      ["github.com", "GitHub"],
      ["stackoverflow.com", "Stack Overflow"],
      ["google.com", "Google"],
      ["youtube.com", "YouTube"],
      ["docs.microsoft.com", "Microsoft Docs"],
      ["medium.com", "Medium"],
      ["npmjs.com", "npm"],
      ["docs.rs", "Rust Docs"]
    ];
  }
});

// src/db/tab-repo.ts
var tab_repo_exports = {};
__export(tab_repo_exports, {
  findDuplicate: () => findDuplicate,
  getTab: () => getTab,
  listTabsByGroup: () => listTabsByGroup,
  listTabsByWorkspace: () => listTabsByWorkspace,
  removeTab: () => removeTab,
  setTabGroup: () => setTabGroup2,
  syncActiveByUrl: () => syncActiveByUrl,
  syncActiveToAllWorkspaces: () => syncActiveToAllWorkspaces,
  updateTabWindow: () => updateTabWindow,
  upsertTab: () => upsertTab
});
function toApi4(row, tw) {
  return {
    id: row.id,
    window_id: row.windowId,
    chrome_tab_id: row.chromeTabId,
    workspace_id: tw?.workspaceId ?? 0,
    group_id: tw?.groupId ?? 0,
    title: row.title,
    url: row.url,
    url_hash: row.urlHash,
    active: (tw?.active ?? 0) !== 0,
    created_at: row.createdAt,
    updated_at: row.updatedAt
  };
}
async function ungroupedGroupId(workspaceId) {
  const db = await getDb();
  const idx = db.transaction("tabGroups").store.index("workspaceId");
  let cursor = await idx.openCursor(workspaceId);
  while (cursor) {
    if (cursor.value.name === "Ungrouped") return cursor.value.id;
    cursor = await cursor.continue();
  }
  const { createTabGroup: createTabGroup2 } = await Promise.resolve().then(() => (init_tabgroup_repo(), tabgroup_repo_exports));
  const g = await createTabGroup2(workspaceId, "Ungrouped", "gray");
  return g.id;
}
async function linkWorkspace(tabId, workspaceId, active, groupId) {
  if (workspaceId <= 0) return;
  const db = await getDb();
  const tx = db.transaction("tabWorkspaces", "readwrite");
  const idx = tx.store.index("tabWorkspace");
  const existing = await idx.get([tabId, workspaceId]);
  if (existing) {
    if (existing.active !== (active ? 1 : 0) || existing.groupId !== groupId) {
      existing.active = active ? 1 : 0;
      existing.groupId = groupId;
      await tx.store.put(existing);
    }
    await tx.done;
    return;
  }
  await tx.done;
  await db.add("tabWorkspaces", {
    tabId,
    workspaceId,
    active: active ? 1 : 0,
    groupId,
    addedAt: now()
  });
}
async function upsertTab(tab) {
  const db = await getDb();
  const urlHash = hashUrl(tab.url);
  const active = tab.active ?? false;
  if (tab.snapshot) {
    const explicitGroup2 = (tab.group_id ?? 0) > 0 ? tab.group_id : 0;
    const twRows2 = (await db.getAll("tabWorkspaces")).filter((r) => r.workspaceId === tab.workspace_id);
    for (const twRow of twRows2) {
      if (!twRow.tabId) continue;
      const existingTab = await db.get("tabs", twRow.tabId);
      if (existingTab && existingTab.urlHash === urlHash) {
        if (explicitGroup2 > 0) {
          const tw3 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [existingTab.id, tab.workspace_id]);
          if (tw3 && tw3.groupId !== explicitGroup2) {
            tw3.groupId = explicitGroup2;
            await db.put("tabWorkspaces", tw3);
          }
        }
        const tw23 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [existingTab.id, tab.workspace_id]);
        return toApi4(existingTab, tw23);
      }
    }
    const id2 = await db.add("tabs", {
      windowId: 0,
      chromeTabId: -(Date.now() + Math.random()),
      title: tab.title,
      url: tab.url,
      urlHash,
      createdAt: now(),
      updatedAt: now()
    });
    const row2 = await db.get("tabs", id2);
    row2.chromeTabId = -id2;
    await db.put("tabs", row2);
    if (explicitGroup2 > 0) {
      await linkWorkspace(id2, tab.workspace_id, active, explicitGroup2);
    } else {
      await linkWorkspace(id2, tab.workspace_id, active, 0);
      const { autoGroupTab: autoGroupTab2 } = await Promise.resolve().then(() => (init_autogroup_repo(), autogroup_repo_exports));
      await autoGroupTab2(id2, tab.workspace_id, urlHash);
      const tw3 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [id2, tab.workspace_id]);
      if (tw3 && tw3.groupId === 0) {
        const ugId = await ungroupedGroupId(tab.workspace_id);
        if (ugId > 0) {
          tw3.groupId = ugId;
          await db.put("tabWorkspaces", tw3);
        }
      }
    }
    const tw22 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [id2, tab.workspace_id]);
    return toApi4(row2, tw22);
  }
  const tx = db.transaction("tabs", "readwrite");
  const idx = tx.store.index("windowChrome");
  const existing = await idx.get([tab.window_id, tab.chrome_tab_id]);
  if (existing) {
    existing.title = tab.title;
    existing.url = tab.url;
    existing.urlHash = urlHash;
    existing.updatedAt = now();
    await tx.store.put(existing);
    await tx.done;
    const explicitGroup2 = (tab.group_id ?? 0) > 0 ? tab.group_id : 0;
    await linkWorkspace(existing.id, tab.workspace_id, active, explicitGroup2 > 0 ? explicitGroup2 : 0);
    if (explicitGroup2 <= 0) {
      const { autoGroupTab: autoGroupTab2 } = await Promise.resolve().then(() => (init_autogroup_repo(), autogroup_repo_exports));
      await autoGroupTab2(existing.id, tab.workspace_id, urlHash);
      const twCheck = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [existing.id, tab.workspace_id]);
      if (twCheck && twCheck.groupId === 0) {
        const ugId = await ungroupedGroupId(tab.workspace_id);
        if (ugId > 0) {
          twCheck.groupId = ugId;
          await db.put("tabWorkspaces", twCheck);
        }
      }
    }
    const tw3 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [existing.id, tab.workspace_id]);
    return toApi4(existing, tw3);
  }
  await tx.done;
  const twRows = (await db.getAll("tabWorkspaces")).filter((r) => r.workspaceId === tab.workspace_id);
  for (const twRow of twRows) {
    if (!twRow.tabId) continue;
    const t = await db.get("tabs", twRow.tabId);
    if (t && t.urlHash === urlHash) {
      const conflict = await db.getFromIndex("tabs", "windowChrome", [tab.window_id, tab.chrome_tab_id]);
      if (!conflict || conflict.id === t.id) {
        t.windowId = tab.window_id;
        t.chromeTabId = tab.chrome_tab_id;
      }
      t.title = tab.title;
      t.updatedAt = now();
      await db.put("tabs", t);
      const urlExplicitGroup = (tab.group_id ?? 0) > 0 ? tab.group_id : 0;
      await linkWorkspace(t.id, tab.workspace_id, active, urlExplicitGroup > 0 ? urlExplicitGroup : 0);
      if (urlExplicitGroup <= 0) {
        const { autoGroupTab: autoGroupTab2 } = await Promise.resolve().then(() => (init_autogroup_repo(), autogroup_repo_exports));
        await autoGroupTab2(t.id, tab.workspace_id, urlHash);
        const twCheck = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [t.id, tab.workspace_id]);
        if (twCheck && twCheck.groupId === 0) {
          const ugId = await ungroupedGroupId(tab.workspace_id);
          if (ugId > 0) {
            twCheck.groupId = ugId;
            await db.put("tabWorkspaces", twCheck);
          }
        }
      }
      const tw22 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [t.id, tab.workspace_id]);
      return toApi4(t, tw22);
    }
  }
  const explicitGroup = (tab.group_id ?? 0) > 0 ? tab.group_id : 0;
  const id = await db.put("tabs", {
    windowId: tab.window_id,
    chromeTabId: tab.chrome_tab_id,
    title: tab.title,
    url: tab.url,
    urlHash,
    createdAt: now(),
    updatedAt: now()
  });
  await linkWorkspace(id, tab.workspace_id, active, explicitGroup > 0 ? explicitGroup : 0);
  if (explicitGroup <= 0) {
    const { autoGroupTab: autoGroupTab2 } = await Promise.resolve().then(() => (init_autogroup_repo(), autogroup_repo_exports));
    await autoGroupTab2(id, tab.workspace_id, urlHash);
  }
  const tw = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [id, tab.workspace_id]);
  if (tw && tw.groupId === 0) {
    const ugId = await ungroupedGroupId(tab.workspace_id);
    if (ugId > 0) {
      tw.groupId = ugId;
      await db.put("tabWorkspaces", tw);
    }
  }
  const row = await db.get("tabs", id);
  const tw2 = await db.getFromIndex("tabWorkspaces", "tabWorkspace", [id, tab.workspace_id]);
  return toApi4(row, tw2);
}
async function removeTab(windowId, chromeTabId, currentWsId, tabDbId) {
  const db = await getDb();
  let existing;
  if (tabDbId != null && tabDbId > 0) {
    existing = await db.transaction("tabs").store.get(tabDbId);
    if (existing) {
      if (existing.windowId !== windowId || existing.chromeTabId !== chromeTabId) {
        console.debug(
          "[removeTab] PK lookup succeeded but coordinates differ:",
          { caller: [windowId, chromeTabId], stored: [existing.windowId, existing.chromeTabId], tabId: tabDbId }
        );
      }
      if (existing.chromeTabId > 0 && windowId === 0 && chromeTabId === 0) {
        console.warn(
          "[removeTab] Deleting live browser tab via PK fallback \u2014 caller had snapshot coordinates (0,0).",
          { tabId: tabDbId, storedWindowId: existing.windowId, storedChromeTabId: existing.chromeTabId }
        );
      }
    }
  }
  if (!existing && (windowId > 0 || chromeTabId > 0)) {
    const row = await db.transaction("tabs").store.index("windowChrome").get([windowId, chromeTabId]);
    if (row) existing = row;
  }
  if (!existing && windowId === 0 && chromeTabId < 0) {
    existing = await db.transaction("tabs").store.get(-chromeTabId);
  }
  if (!existing) {
    console.warn(
      "[removeTab] Unable to find tab row \u2014 all lookups failed.",
      { windowId, chromeTabId, currentWsId, tabDbId }
    );
    return false;
  }
  const tabId = existing.id;
  const tx = db.transaction("tabWorkspaces", "readwrite");
  const twIdx = tx.store.index("tabWorkspace");
  const tw = await twIdx.get([tabId, currentWsId]);
  if (tw) await tx.store.delete(tw.id);
  const allTw = await tx.store.getAll();
  for (const row of allTw) {
    if (row.tabId === tabId && row.workspaceId !== currentWsId) {
      row.active = 0;
      await tx.store.put(row);
    }
  }
  await tx.done;
  const remaining = (await db.getAll("tabWorkspaces")).filter((r) => r.tabId === tabId);
  if (remaining.length === 0) {
    await db.delete("tabs", tabId);
  }
  return true;
}
async function findDuplicate(url) {
  const db = await getDb();
  const urlHash = hashUrl(url);
  const all = await db.getAll("tabs");
  let simRules = [];
  try {
    simRules = await loadSimilarityRules();
  } catch {
  }
  const ruleHash = simRules.length > 0 ? hashUrlWithRules(url, simRules) : urlHash;
  for (const t of all) {
    if (t.chromeTabId > 0) {
      const matchesDefault = t.urlHash === urlHash;
      const matchesRule = simRules.length > 0 && t.urlHash === ruleHash;
      if (matchesDefault || matchesRule) {
        if (simRules.length > 0) {
          const tRuleHash = hashUrlWithRules(t.url, simRules);
          if (tRuleHash !== ruleHash) continue;
        }
        return {
          duplicate: true,
          tab: { chrome_tab_id: t.chromeTabId, window_id: t.windowId, title: t.title }
        };
      }
    }
  }
  return { duplicate: false, tab: null };
}
async function syncActiveToAllWorkspaces(windowId, chromeTabId, active) {
  const db = await getDb();
  const idx = db.transaction("tabs").store.index("windowChrome");
  const tab = await idx.get([windowId, chromeTabId]);
  if (!tab) return;
  const tx = db.transaction("tabWorkspaces", "readwrite");
  const all = await tx.store.getAll();
  for (const tw of all) {
    if (tw.tabId === tab.id) {
      tw.active = active ? 1 : 0;
      await tx.store.put(tw);
    }
  }
  await tx.done;
}
async function syncActiveByUrl(url) {
  const db = await getDb();
  const urlHash = hashUrl(url);
  const allTabs = await db.getAll("tabs");
  const matchingIds = new Set(allTabs.filter((t) => t.urlHash === urlHash).map((t) => t.id));
  if (matchingIds.size === 0) return;
  const tx = db.transaction("tabWorkspaces", "readwrite");
  const allTw = await tx.store.getAll();
  for (const tw of allTw) {
    if (matchingIds.has(tw.tabId)) {
      tw.active = 1;
      await tx.store.put(tw);
    }
  }
  await tx.done;
}
async function setTabGroup2(tabId, workspaceId, groupId) {
  const db = await getDb();
  const idx = db.transaction("tabWorkspaces", "readwrite").store.index("tabWorkspace");
  const tw = await idx.get([tabId, workspaceId]);
  if (tw) {
    tw.groupId = groupId;
    await db.put("tabWorkspaces", tw);
  }
}
async function listTabsByWorkspace(workspaceId) {
  const db = await getDb();
  const twIdx = db.transaction("tabWorkspaces").store.index("workspaceId");
  const tws = await twIdx.getAll(workspaceId);
  const result = [];
  for (const tw of tws) {
    const tab = await db.get("tabs", tw.tabId);
    if (tab) result.push(toApi4(tab, tw));
  }
  return result.sort((a, b) => a.id - b.id);
}
async function listTabsByGroup(groupId, workspaceId) {
  const db = await getDb();
  const idx = db.transaction("tabWorkspaces").store.index("workspaceGroup");
  const tws = await idx.getAll([workspaceId, groupId]);
  const result = [];
  for (const tw of tws) {
    const tab = await db.get("tabs", tw.tabId);
    if (tab) result.push(toApi4(tab, tw));
  }
  return result.sort((a, b) => a.id - b.id);
}
async function getTab(id) {
  const db = await getDb();
  const row = await db.get("tabs", id);
  if (!row) return null;
  return toApi4(row);
}
async function updateTabWindow(id, windowId, chromeTabId, title, url) {
  const db = await getDb();
  const row = await db.get("tabs", id);
  if (!row) return;
  row.windowId = windowId;
  row.chromeTabId = chromeTabId;
  row.title = title;
  row.url = url;
  row.urlHash = hashUrl(url);
  row.updatedAt = now();
  await db.put("tabs", row);
}
var init_tab_repo = __esm({
  "src/db/tab-repo.ts"() {
    "use strict";
    init_database();
  }
});

// src/db/workspace-repo.ts
init_database();
var CURRENT_WS_NAME = "Open Tabs";
var migrationDone2 = false;
async function migrateCurrentWsName() {
  if (migrationDone2) return;
  migrationDone2 = true;
  try {
    const db = await getDb();
    const all = await db.getAll("workspaces");
    const legacy = all.filter((w) => w.name === "Current" && w.parentId === 0);
    for (const ws of legacy) {
      ws.name = CURRENT_WS_NAME;
      await db.put("workspaces", ws);
    }
  } catch {
  }
}
function toApi(row) {
  return {
    id: row.id,
    parent_id: row.parentId,
    sort_order: row.sortOrder,
    name: row.name,
    description: row.description,
    icon: row.icon,
    created_at: row.createdAt,
    updated_at: row.updatedAt
  };
}
async function listWorkspaces() {
  const db = await getDb();
  const rows = await db.getAll("workspaces");
  return rows.map(toApi).sort((a, b) => a.parent_id - b.parent_id || a.sort_order - b.sort_order || a.id - b.id);
}
async function getWorkspace(id) {
  const db = await getDb();
  const row = await db.get("workspaces", id);
  return row ? toApi(row) : null;
}
async function createWorkspace(name, description = "", icon = "", parentId = 0, afterId = 0) {
  if (name === CURRENT_WS_NAME && parentId === 0) {
    const db2 = await getDb();
    const all2 = await db2.getAll("workspaces");
    const existing = all2.find((w) => w.name === CURRENT_WS_NAME && w.parentId === 0);
    if (existing) throw new Error(`"${CURRENT_WS_NAME}" workspace already exists`);
  }
  const db = await getDb();
  const tx = db.transaction("workspaces", "readwrite");
  const store = tx.objectStore("workspaces");
  let sortOrder = 0;
  const all = await store.getAll();
  const siblings = all.filter((w) => w.parentId === parentId).sort((a, b) => a.sortOrder - b.sortOrder);
  if (afterId > 0) {
    const after = siblings.find((w) => w.id === afterId);
    if (after) {
      sortOrder = after.sortOrder + 1;
      for (const s of siblings) {
        if (s.sortOrder > after.sortOrder) {
          await store.put({ ...s, sortOrder: s.sortOrder + 1 });
        }
      }
    }
  } else if (siblings.length > 0) {
    sortOrder = siblings[siblings.length - 1].sortOrder + 1;
  }
  const id = await store.add({
    parentId,
    sortOrder,
    name,
    description,
    icon,
    createdAt: now(),
    updatedAt: now()
  });
  await tx.done;
  return await getWorkspace(id);
}
async function deleteWorkspace(id) {
  const db = await getDb();
  const tx = db.transaction(["workspaces", "tabWorkspaces", "tabGroups", "bookmarks"], "readwrite");
  const twIdx = tx.objectStore("tabWorkspaces").index("workspaceId");
  for (let c = await twIdx.openCursor(id); c; c = await c.continue()) {
    c.delete();
  }
  const tgIdx = tx.objectStore("tabGroups").index("workspaceId");
  for (let c = await tgIdx.openCursor(id); c; c = await c.continue()) {
    c.delete();
  }
  const bmIdx = tx.objectStore("bookmarks").index("workspaceId");
  for (let c = await bmIdx.openCursor(id); c; c = await c.continue()) {
    c.delete();
  }
  const parentIdx = tx.objectStore("workspaces").index("parentId");
  const row = await tx.objectStore("workspaces").get(id);
  const newParent = row?.parentId ?? 0;
  for (let c = await parentIdx.openCursor(id); c; c = await c.continue()) {
    c.value.parentId = newParent;
    c.update(c.value);
  }
  tx.objectStore("workspaces").delete(id);
  await tx.done;
}

// src/lib/api.ts
init_tab_repo();
init_tabgroup_repo();

// src/db/bookmark-repo.ts
init_database();

// src/db/session-repo.ts
init_database();

// src/lib/api.ts
init_autogroup_repo();

// src/db/search.ts
init_database();

// src/lib/api.ts
init_database();

// src/lib/export-import.ts
init_database();

// src/lib/api.ts
async function listWorkspaces2() {
  return listWorkspaces();
}
async function createWorkspace2(name, description = "", icon = "", parentId = 0, afterId = 0) {
  return createWorkspace(name, description, icon, parentId, afterId);
}
async function deleteWorkspace2(id) {
  return deleteWorkspace(id);
}
async function listTabs(workspaceId) {
  return listTabsByWorkspace(workspaceId);
}
async function upsertTab2(tab) {
  return upsertTab({
    window_id: tab.window_id ?? 0,
    chrome_tab_id: tab.chrome_tab_id ?? 0,
    workspace_id: tab.workspace_id ?? 0,
    title: tab.title ?? "",
    url: tab.url,
    active: tab.active,
    group_id: tab.group_id,
    snapshot: tab.snapshot
  });
}
async function removeTab2(windowId, chromeTabId, currentWorkspaceId, tabDbId) {
  return removeTab(windowId, chromeTabId, currentWorkspaceId ?? 0, tabDbId);
}
async function findDuplicate2(url) {
  return findDuplicate(url);
}
async function syncActiveByUrl2(url) {
  return syncActiveByUrl(url);
}
async function reapplyAutoGroup2(workspaceId) {
  return { grouped_count: await reapplyAutoGroup(workspaceId) };
}
function normalizeUrlAggressive(u) {
  try {
    const p = new URL(u);
    p.search = "";
    p.hostname = p.hostname.replace(/^www\./, "");
    if (p.pathname.endsWith("/") && p.pathname.length > 1) p.pathname = p.pathname.slice(0, -1);
    return p.toString().toLowerCase();
  } catch {
    return u.toLowerCase();
  }
}

// src/background/index.ts
init_tab_repo();
init_database();
var NEWTAB_URL = "chrome://newtab/";
function notifyTabsChanged() {
  chrome.runtime.sendMessage({ type: "tabs-changed" }).catch(() => {
  });
}
function isNavigable(url) {
  if (!url) return false;
  return url.startsWith("http://") || url.startsWith("https://");
}
function isNewTab(url) {
  if (!url) return true;
  return url === NEWTAB_URL || url === "";
}
var currentWsPromise = null;
async function ensureCurrentWorkspace() {
  if (currentWsPromise) return currentWsPromise;
  currentWsPromise = (async () => {
    const list = await listWorkspaces2();
    const cur = list.find((w) => w.name === CURRENT_WS_NAME);
    if (cur) return cur.id;
    const created = await createWorkspace2(CURRENT_WS_NAME, "Auto-tracked tabs", "");
    const all = await listWorkspaces2();
    const dupes = all.filter((w) => w.name === CURRENT_WS_NAME);
    for (let i = 1; i < dupes.length; i++) {
      try {
        await deleteWorkspace2(dupes[i].id);
      } catch {
      }
    }
    return dupes[0]?.id ?? created.id;
  })().catch((e) => {
    console.warn("[workspace-bg] ensureCurrentWorkspace failed, will retry:", e);
    currentWsPromise = null;
    throw e;
  });
  return currentWsPromise;
}
async function syncTab(tab) {
  if (!isNavigable(tab.url)) return;
  const curId = await ensureCurrentWorkspace();
  await upsertTab2({
    window_id: tab.windowId,
    chrome_tab_id: tab.id,
    workspace_id: curId,
    title: tab.title ?? "",
    url: tab.url,
    active: tab.active || false
  });
  await syncActiveToAllWorkspaces(tab.windowId, tab.id, tab.active || false);
}
async function removeTab3(windowId, tabId) {
  const curId = await ensureCurrentWorkspace();
  await removeTab2(windowId, tabId, curId);
}
var pendingDupes = /* @__PURE__ */ new Map();
async function handleDuplicateAndSwitch(tab) {
  if (!isNavigable(tab.url) || tab.id == null) return false;
  const tabNorm = normalizeUrlAggressive(tab.url);
  if (suppressedDupeUrls.has(tabNorm)) return false;
  const data = await findDuplicate2(tab.url);
  if (!data || !data.duplicate || !data.tab) return false;
  if (data.tab.chrome_tab_id === tab.id && data.tab.window_id === tab.windowId) return false;
  try {
    await chrome.tabs.get(data.tab.chrome_tab_id);
  } catch {
    return false;
  }
  let simRules = [];
  try {
    simRules = await loadSimilarityRules();
  } catch {
  }
  const matchedRule = findRule(tab.url, simRules);
  if (matchedRule && matchedRule.auto_switch) {
    let closed = false;
    try {
      await chrome.tabs.remove(tab.id);
      closed = true;
    } catch {
    }
    if (closed) {
      chrome.windows.update(data.tab.window_id, { focused: true }).catch(() => {
      });
      chrome.tabs.update(data.tab.chrome_tab_id, { active: true }).catch(() => {
      });
      return true;
    }
  }
  const notifId = `dup-${tab.id}-${Date.now()}`;
  pendingDupes.set(notifId, {
    newTabId: tab.id,
    newWindowId: tab.windowId ?? 0,
    existingTabId: data.tab.chrome_tab_id,
    existingWindowId: data.tab.window_id
  });
  try {
    await chrome.notifications.create(notifId, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Duplicate Page",
      message: `"${data.tab.title || tab.url}" is already open.
Switch to the existing tab?`,
      buttons: [{ title: "Switch to existing" }, { title: "Keep both" }],
      priority: 2
    });
  } catch {
    pendingDupes.delete(notifId);
  }
  return false;
}
async function resolveDupe(notifId, switchToExisting) {
  const info = pendingDupes.get(notifId);
  if (!info) return;
  pendingDupes.delete(notifId);
  if (switchToExisting) {
    try {
      await chrome.tabs.remove(info.newTabId);
      chrome.windows.update(info.existingWindowId, { focused: true }).catch(() => {
      });
      chrome.tabs.update(info.existingTabId, { active: true }).catch(() => {
      });
    } catch {
    }
  }
}
var suppressedDupeUrls = /* @__PURE__ */ new Set();
function suppressDupesForUrls(urls, durationMs = 8e3) {
  for (const u of urls) {
    try {
      suppressedDupeUrls.add(normalizeUrlAggressive(u));
    } catch {
      suppressedDupeUrls.add(u.toLowerCase());
    }
  }
  setTimeout(() => {
    for (const u of urls) {
      try {
        suppressedDupeUrls.delete(normalizeUrlAggressive(u));
      } catch {
        suppressedDupeUrls.delete(u.toLowerCase());
      }
    }
  }, durationMs);
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "suppress-dupes" && Array.isArray(msg.urls)) {
    suppressDupesForUrls(msg.urls, msg.durationMs ?? 8e3);
  }
  if (msg.type === "reapply-auto-group") {
    (async () => {
      const curId = await ensureCurrentWorkspace();
      if (curId > 0) {
        await reapplyAutoGroup2(curId);
        notifyTabsChanged();
      }
    })().catch(() => {
    });
  }
});
chrome.notifications?.onButtonClicked?.addListener?.((notifId, btnIdx) => {
  if (!notifId.startsWith("dup-")) return;
  resolveDupe(notifId, btnIdx === 0);
});
chrome.notifications?.onClicked?.addListener?.((notifId) => {
  if (!notifId.startsWith("dup-")) return;
  resolveDupe(notifId, true);
});
chrome.notifications?.onClosed?.addListener?.((notifId) => {
  if (!notifId.startsWith("dup-")) return;
  pendingDupes.delete(notifId);
});
async function enforceSingleNewTab(newTabId) {
  if (newTabId == null) return;
  try {
    const allNewTabs = await chrome.tabs.query({ url: NEWTAB_URL });
    if (allNewTabs.length <= 1) return;
    const sorted = allNewTabs.sort((a, b) => (b.id ?? 0) - (a.id ?? 0));
    const [keep, ...rest] = sorted;
    if (!keep) return;
    for (const t of rest) {
      try {
        if (t.id != null) await chrome.tabs.remove(t.id);
      } catch {
      }
    }
    if (keep.windowId != null && keep.id != null) {
      await chrome.windows.update(keep.windowId, { focused: true });
      await chrome.tabs.update(keep.id, { active: true });
    }
  } catch {
  }
}
async function safeSyncAndNotify(tab) {
  try {
    await syncTab(tab);
  } catch (e) {
    console.warn("[workspace-bg] syncTab failed:", e);
  }
  try {
    notifyTabsChanged();
  } catch {
  }
}
chrome.tabs.onCreated.addListener((tab) => {
  if (isNewTab(tab.pendingUrl) || isNewTab(tab.url)) {
    enforceSingleNewTab(tab.id);
    return;
  }
  if (isNavigable(tab.url)) {
    handleDuplicateAndSwitch(tab).then((switched) => {
      if (!switched) safeSyncAndNotify(tab);
    }).catch(() => {
    });
  }
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  try {
    if (changeInfo.url && isNewTab(changeInfo.url)) {
      enforceSingleNewTab(tabId);
      return;
    }
    if (changeInfo.url && isNavigable(changeInfo.url)) {
      const tabWithUrl = { ...tab, url: changeInfo.url };
      const switched = await handleDuplicateAndSwitch(tabWithUrl);
      if (switched) return;
      await safeSyncAndNotify(tabWithUrl);
    }
    if ((changeInfo.title || tab?.status === "complete") && isNavigable(tab?.url)) {
      await safeSyncAndNotify(tab);
    }
  } catch (e) {
    console.warn("[workspace-bg] onUpdated error:", e);
  }
});
chrome.tabs.onRemoved.addListener(async (tabId, { windowId }) => {
  try {
    await removeTab3(windowId, tabId);
    notifyTabsChanged();
  } catch (e) {
    console.warn("[workspace-bg] onRemoved error:", e);
  }
});
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    await syncTab(tab);
    if (isNavigable(tab.url)) await syncActiveByUrl2(tab.url);
    notifyTabsChanged();
  } catch {
  }
});
chrome.tabs.onAttached.addListener(async (tabId) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    await safeSyncAndNotify(tab);
  } catch {
  }
});
chrome.tabs.onDetached.addListener(() => {
  notifyTabsChanged();
});
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  notifyTabsChanged();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
});
chrome.commands.onCommand.addListener((command) => {
  if (command === "quick-search") {
    chrome.runtime.sendMessage({ type: "focus-search" }).catch(() => {
    });
  }
});
var periodicSyncRunning = false;
async function periodicFullSync() {
  if (periodicSyncRunning) return;
  periodicSyncRunning = true;
  try {
    const curId = await ensureCurrentWorkspace();
    const browserTabs = await chrome.tabs.query({});
    let synced = 0;
    for (const tab of browserTabs) {
      if (!isNavigable(tab.url)) continue;
      try {
        await upsertTab2({
          window_id: tab.windowId,
          chrome_tab_id: tab.id,
          workspace_id: curId,
          title: tab.title ?? "",
          url: tab.url,
          active: tab.active
        });
        synced++;
      } catch {
      }
    }
    const liveIds = new Set(
      browserTabs.map((t) => t.id).filter((id) => id != null)
    );
    const allDbTabs = await listTabs(curId);
    let cleaned = 0;
    for (const dbTab of allDbTabs) {
      if (dbTab.chrome_tab_id > 0 && !liveIds.has(dbTab.chrome_tab_id)) {
        try {
          await removeTab2(dbTab.window_id, dbTab.chrome_tab_id, curId, dbTab.id);
          cleaned++;
        } catch {
        }
      }
    }
    try {
      await reapplyAutoGroup2(curId);
    } catch {
    }
    if (synced > 0 || cleaned > 0) {
      console.log(`[workspace-bg] Periodic sync: ${synced} synced, ${cleaned} cleaned`);
      notifyTabsChanged();
    }
  } catch {
  } finally {
    periodicSyncRunning = false;
  }
}
chrome.alarms.create("full-sync", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "full-sync") periodicFullSync();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.similarityRules) {
    Promise.resolve().then(() => (init_database(), database_exports)).then(({ invalidateSimRulesCache: invalidateSimRulesCache2 }) => invalidateSimRulesCache2());
  }
});
async function onStartupOrInstall() {
  try {
    const curId = await ensureCurrentWorkspace();
    if (curId > 0) {
      const stored = await new Promise((resolve) => {
        chrome.storage.local.get("currentWorkspaceId", (r) => resolve(r.currentWorkspaceId || 0));
      });
      if (stored <= 0) chrome.storage.local.set({ currentWorkspaceId: curId });
      await periodicFullSync();
    }
  } catch (e) {
    console.warn("[workspace-bg] startup error:", e);
  }
}
migrateCurrentWsName().catch(() => {
});
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") chrome.runtime.openOptionsPage();
  onStartupOrInstall();
});
chrome.runtime.onStartup.addListener(() => onStartupOrInstall());
onStartupOrInstall();
console.log("[workspace-bg] standalone service worker started");
